#include "ctap.h"

TESTS {
    ok(1 == 1, "1 does in fact equal 1");

    TODO("Not yet finished") {
        ok(1, "should work fine");
    }
}
