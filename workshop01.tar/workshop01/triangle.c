#include <stdio.h>

int main(int argc, const char *argv[]) {

    /* Replace this comment with your code */

    return 0;
}
