#include <stdio.h>

#define PI 3.141592

double area(double radius);
/* Add a new function prototype here for the circumference */

int main(int argc, const char *argv[]) {
    printf("Enter a radius in metres: ");
    double radius = 0.0;
    const int result = scanf("%lf", &radius);

    // True if the user's value was assigned to radius
    if (result > 0) {
        printf("Area: %.2lfm\n", area(radius));
    }
    
    return 0;
}

double area(double radius) {
    /* Modify this function so it returns the correct value */
    return 0;
}

/* Add the implementation for the circumference function here */
