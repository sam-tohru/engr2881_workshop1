#include <stdio.h>

int main() {
  printf("Success!\nYou've just completed the first task.\n");
  return 0;
}
